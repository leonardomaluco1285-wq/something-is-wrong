# Revisao tecnica — Something Is Wrong

## Ajustes aplicados nesta revisao

- Fixada a versao do Fabric Loom em `1.8.13` em vez de depender da versao `1.8-SNAPSHOT`.
- Os handlers de pacotes do cliente agora agendam alteracoes de HUD/tela na thread principal do Minecraft.

## Estado de verificacao

O arquivo original nao inclui `gradlew`, `gradlew.bat` nem `gradle-wrapper.jar`. O ambiente desta revisao tem Java 21, mas nao tem Gradle instalado e nao consegue resolver o host `services.gradle.org`; por isso nao foi possivel baixar o Gradle, resolver as dependencias Fabric/Minecraft, executar `build` ou produzir honestamente um JAR compilado.

A revisao dos arquivos e uma verificacao estatica, nao substitui a compilacao com Loom nem um teste dentro do jogo. Nao considere o mod validado ate executar os passos abaixo num computador com acesso aos repositorios Maven.

## Como validar em um computador com Gradle instalado

Na pasta `siw`:

```bash
gradle wrapper --gradle-version 8.10.2
./gradlew clean build
```

No Windows, use `gradlew.bat clean build` depois de gerar o wrapper. O JAR remapeado deve aparecer em `build/libs/`. Para testar no cliente de desenvolvimento:

```bash
./gradlew runClient
```

Se a compilacao apontar incompatibilidade de API, corrija a assinatura indicada pelo compilador para Minecraft 1.21.1/Yarn build.3 e rode novamente os testes e a compilacao.
