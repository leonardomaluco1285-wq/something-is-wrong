package com.leonardo.somethingiswrong.client;

import com.leonardo.somethingiswrong.config.ConfigManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/**
 * Interferencia visual controlada, desenhada so na camada de HUD:
 * - duracao limitada (<= 200 ticks) e com fade suave (sem estroboscopio);
 * - nunca aparece sobre telas (abrir ESC/inventario/qualquer menu a esconde);
 * - desligavel na config (visualInterference) e limpa ao desconectar.
 */
public final class InterferenceHud {
    private static int total = 0;
    private static int remaining = 0;
    private static int intensity = 0;
    private static int frameSeed = 0;

    private InterferenceHud() {}

    public static void start(int durationTicks, int intensityPercent) {
        if (!ConfigManager.get().visualInterference) return;
        total = Math.max(1, Math.min(durationTicks, 200));
        remaining = total;
        intensity = Math.max(0, Math.min(intensityPercent, 100));
    }

    public static void clear() {
        remaining = 0;
        total = 0;
    }

    public static void tick(MinecraftClient client) {
        if (remaining <= 0) return;
        if (client.world == null) { clear(); return; }
        remaining--;
        if (remaining % 4 == 0) frameSeed = (frameSeed * 1103515245 + 12345) & 0x7fffffff;
    }

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        if (remaining <= 0 || !ConfigManager.get().visualInterference) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.currentScreen != null) return;
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();

        // envelope suave: sobe e desce em seno
        double progress = 1.0 - (remaining / (double) total);
        double envelope = Math.sin(Math.PI * progress);
        double strength = envelope * (intensity / 100.0);
        if (strength <= 0.01) return;

        // vinheta escura nas bordas
        int edgeAlpha = (int) (strength * 90);
        int edge = Math.max(6, h / 10);
        ctx.fill(0, 0, w, edge, argb(edgeAlpha, 0, 0, 0));
        ctx.fill(0, h - edge, w, h, argb(edgeAlpha, 0, 0, 0));
        ctx.fill(0, 0, edge, h, argb(edgeAlpha / 2, 0, 0, 0));
        ctx.fill(w - edge, 0, w, h, argb(edgeAlpha / 2, 0, 0, 0));

        // faixas horizontais cinza-azuladas (deslocam-se a cada 4 ticks, nao a cada quadro)
        int bars = 3 + (int) (strength * 5);
        int seed = frameSeed;
        for (int i = 0; i < bars; i++) {
            seed = (seed * 1664525 + 1013904223) & 0x7fffffff;
            int y = seed % Math.max(1, h - 4);
            int bh = 1 + (seed >> 8) % 3;
            ctx.fill(0, y, w, Math.min(h, y + bh), argb((int) (strength * 45), 150, 165, 180));
        }
    }

    private static int argb(int a, int r, int g, int b) {
        return (Math.max(0, Math.min(255, a)) << 24) | (r << 16) | (g << 8) | b;
    }
}
