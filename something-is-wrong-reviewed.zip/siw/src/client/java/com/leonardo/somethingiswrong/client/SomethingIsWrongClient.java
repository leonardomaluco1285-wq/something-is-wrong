package com.leonardo.somethingiswrong.client;

import com.leonardo.somethingiswrong.entity.ModEntities;
import com.leonardo.somethingiswrong.net.EndingPayload;
import com.leonardo.somethingiswrong.net.InterferencePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

/** Entrada do cliente: renderizador, interferencia visual (HUD) e tela de encerramento. */
public class SomethingIsWrongClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.THE_WATCHER, WatcherRenderer::new);

        // Packet callbacks are not guaranteed to run on the render thread. Schedule all
        // client UI/HUD mutations on the Minecraft client thread.
        ClientPlayNetworking.registerGlobalReceiver(InterferencePayload.ID,
                (payload, context) -> context.client().execute(
                        () -> InterferenceHud.start(payload.durationTicks(), payload.intensity())));
        ClientPlayNetworking.registerGlobalReceiver(EndingPayload.ID,
                (payload, context) -> context.client().execute(
                        () -> context.client().setScreen(new EndingScreen())));

        HudRenderCallback.EVENT.register(InterferenceHud::render);
        ClientTickEvents.END_CLIENT_TICK.register(client -> InterferenceHud.tick(client));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> InterferenceHud.clear());
    }
}
