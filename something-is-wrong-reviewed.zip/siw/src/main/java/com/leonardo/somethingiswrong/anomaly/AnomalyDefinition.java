package com.leonardo.somethingiswrong.anomaly;

import java.util.EnumSet;
import java.util.Set;

/** Definicao declarativa de uma anomalia. A execucao (efeitos) fica na camada do servidor. */
public final class AnomalyDefinition {
    public final String id;
    /** Janela permitida em segundos "base" (campanha de 20 min). */
    public final int startBaseSeconds;
    public final int endBaseSeconds;
    public final int weight;
    /** Chance (0..1) de executar quando selecionada. */
    public final double baseChance;
    /** Espera minima antes de repetir, em ticks da campanha. */
    public final long cooldownTicks;
    public final int maxRepeats;
    public final Set<Requirement> requirements;
    /** Se verdadeiro, e executada na primeira oportunidade elegivel da janela (ex.: primeira aparicao). */
    public final boolean mustRunOnce;
    /** Se verdadeiro, nunca e sorteada (executada por script, ex.: final). */
    public final boolean scripted;
    /** Se verdadeiro, depende de interferencia visual estar ativada. */
    public final boolean needsVisual;

    public AnomalyDefinition(String id, int startBaseSeconds, int endBaseSeconds, int weight, double baseChance,
                             long cooldownTicks, int maxRepeats, Set<Requirement> requirements,
                             boolean mustRunOnce, boolean scripted, boolean needsVisual) {
        this.id = id;
        this.startBaseSeconds = startBaseSeconds;
        this.endBaseSeconds = endBaseSeconds;
        this.weight = weight;
        this.baseChance = baseChance;
        this.cooldownTicks = cooldownTicks;
        this.maxRepeats = maxRepeats;
        this.requirements = requirements.isEmpty() ? EnumSet.noneOf(Requirement.class) : EnumSet.copyOf(requirements);
        this.mustRunOnce = mustRunOnce;
        this.scripted = scripted;
        this.needsVisual = needsVisual;
    }

    public static AnomalyDefinition of(String id, int startSec, int endSec, int weight, double chance,
                                       long cooldownSeconds, int maxRepeats, Requirement... reqs) {
        Set<Requirement> r = EnumSet.noneOf(Requirement.class);
        for (Requirement q : reqs) r.add(q);
        return new AnomalyDefinition(id, startSec, endSec, weight, chance, cooldownSeconds * 20L, maxRepeats, r, false, false, false);
    }

    public AnomalyDefinition withMustRunOnce() {
        return new AnomalyDefinition(id, startBaseSeconds, endBaseSeconds, weight, baseChance, cooldownTicks, maxRepeats,
                requirements, true, scripted, needsVisual);
    }

    public AnomalyDefinition withNeedsVisual() {
        return new AnomalyDefinition(id, startBaseSeconds, endBaseSeconds, weight, baseChance, cooldownTicks, maxRepeats,
                requirements, mustRunOnce, scripted, true);
    }

    public static AnomalyDefinition scripted(String id, int atBaseSeconds) {
        return new AnomalyDefinition(id, atBaseSeconds, atBaseSeconds + 600, 0, 1.0, 0, 1,
                EnumSet.noneOf(Requirement.class), false, true, false);
    }
}
