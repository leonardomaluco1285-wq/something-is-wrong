package com.leonardo.somethingiswrong.anomaly;

import com.leonardo.somethingiswrong.campaign.CampaignState;
import com.leonardo.somethingiswrong.campaign.ExecutionRecord;
import com.leonardo.somethingiswrong.campaign.Phase;
import com.leonardo.somethingiswrong.config.ModSettings;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

/** Selecao ponderada de anomalias respeitando janelas, intervalos, limites e condicoes. */
public final class AnomalyScheduler {
    /** Intervalo entre tentativas de sorteio (ticks da campanha). */
    public static final long ATTEMPT_INTERVAL_TICKS = 100;
    /** Densidade por fase: multiplica a chance final. */
    private static final double[] DENSITY = {0.0, 0.6, 0.8, 1.0, 1.2, 1.5, 2.0};

    private AnomalyScheduler() {}

    public static long globalGapTicks(ModSettings cfg) {
        return Math.max(100, Math.round(400.0 / cfg.eventFrequency));
    }

    /** Retorna o motivo da rejeicao, ou null se a anomalia pode executar agora. */
    public static String rejection(AnomalyDefinition d, CampaignState st, ModSettings cfg, SafetyContext ctx, long now) {
        if (!cfg.enabled) return "disabled";
        if (!st.started) return "not_started";
        if (d.scripted) return "scripted";
        double sec = Phase.baseSeconds(now, cfg.campaignMinutes);
        if (sec < d.startBaseSeconds || sec >= d.endBaseSeconds) return "window";
        if (d.needsVisual && !cfg.visualInterference) return "visual_off";
        if (st.countOf(d.id) >= d.maxRepeats) return "max_repeats";
        long last = st.lastTickOf(d.id);
        if (last >= 0 && now - last < d.cooldownTicks) return "cooldown";
        if (st.lastAnyEventTick >= 0 && now - st.lastAnyEventTick < globalGapTicks(cfg)) return "global_gap";
        if (!ctx.isSafeForEvents()) return "unsafe";
        for (Requirement r : d.requirements) {
            if (!r.test(ctx)) return "requirement:" + r.name();
        }
        return null;
    }

    public static double effectiveChance(AnomalyDefinition d, CampaignState st, ModSettings cfg, long now) {
        Phase p = Phase.atBaseSeconds(Phase.baseSeconds(now, cfg.campaignMinutes));
        double density = DENSITY[Math.min(p.ordinal(), DENSITY.length - 1)];
        double c = d.baseChance * cfg.intensityMultiplier() * cfg.eventFrequency * density * cfg.chanceMultiplierFor(d.id);
        return Math.max(0.0, Math.min(1.0, c));
    }

    public static List<AnomalyDefinition> eligible(List<AnomalyDefinition> all, CampaignState st, ModSettings cfg,
                                                   SafetyContext ctx, long now) {
        List<AnomalyDefinition> out = new ArrayList<>();
        for (AnomalyDefinition d : all) {
            if (rejection(d, st, cfg, ctx, now) == null) out.add(d);
        }
        return out;
    }

    /** Escolhe (ou nao) uma anomalia para esta tentativa. */
    public static Optional<AnomalyDefinition> select(List<AnomalyDefinition> all, CampaignState st, ModSettings cfg,
                                                     SafetyContext ctx, long now, Random rnd) {
        List<AnomalyDefinition> el = eligible(all, st, cfg, ctx, now);
        if (el.isEmpty()) return Optional.empty();
        for (AnomalyDefinition d : el) {
            if (d.mustRunOnce && st.countOf(d.id) == 0) return Optional.of(d);
        }
        int total = 0;
        for (AnomalyDefinition d : el) total += Math.max(0, d.weight);
        if (total <= 0) return Optional.empty();
        int roll = rnd.nextInt(total);
        AnomalyDefinition pick = el.get(0);
        for (AnomalyDefinition d : el) {
            roll -= Math.max(0, d.weight);
            if (roll < 0) { pick = d; break; }
        }
        double chance = effectiveChance(pick, st, cfg, now);
        return rnd.nextDouble() < chance ? Optional.of(pick) : Optional.empty();
    }

    /** Registra a execucao no estado persistente. */
    public static void record(CampaignState st, AnomalyDefinition d, long now) {
        ExecutionRecord r = st.executed.computeIfAbsent(d.id, k -> new ExecutionRecord(0, -1));
        r.count++;
        r.lastTick = now;
        st.lastEventId = d.id;
        st.lastEventTick = now;
        st.lastAnyEventTick = now;
    }
}
