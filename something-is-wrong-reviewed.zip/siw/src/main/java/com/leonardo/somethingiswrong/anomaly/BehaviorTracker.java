package com.leonardo.somethingiswrong.anomaly;

/** Observa o comportamento do jogador (1 amostra por segundo, janela de 60 s) para a anomalia adaptativa. */
public final class BehaviorTracker {
    public enum Trait { NONE, STATIONARY, UNDERGROUND, EXPLORER, LOOKER }

    public static final int WINDOW = 60;
    private static final int MIN_SAMPLES = 20;
    private static final int MOVING = 0, STILL = 1, UNDER = 2;

    private final int[] ring = new int[WINDOW];
    private int count = 0;
    private int head = 0;
    private int watcherLooks = 0;

    public void sample(boolean stationary, boolean underground) {
        int v = underground ? UNDER : (stationary ? STILL : MOVING);
        ring[head] = v;
        head = (head + 1) % WINDOW;
        if (count < WINDOW) count++;
    }

    public void noteWatcherLook() { watcherLooks++; }

    public void consumeLooks() { watcherLooks = 0; }

    public Trait dominant() {
        if (watcherLooks >= 2) return Trait.LOOKER;
        if (count < MIN_SAMPLES) return Trait.NONE;
        int still = 0, under = 0, moving = 0;
        for (int i = 0; i < count; i++) {
            switch (ring[i]) {
                case STILL -> still++;
                case UNDER -> under++;
                default -> moving++;
            }
        }
        if (still * 10 >= count * 6) return Trait.STATIONARY;
        if (under * 10 >= count * 6) return Trait.UNDERGROUND;
        if (moving * 2 >= count) return Trait.EXPLORER;
        return Trait.NONE;
    }
}
