package com.leonardo.somethingiswrong.anomaly;

/** Condicoes de ativacao de uma anomalia (alem da seguranca geral). */
public enum Requirement {
    OUTDOORS, UNDERGROUND, NO_WATCHER;

    public boolean test(SafetyContext c) {
        return switch (this) {
            case OUTDOORS -> !c.underground();
            case UNDERGROUND -> c.underground();
            case NO_WATCHER -> !c.watcherPresent();
        };
    }
}
