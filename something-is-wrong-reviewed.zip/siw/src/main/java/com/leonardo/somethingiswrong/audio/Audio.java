package com.leonardo.somethingiswrong.audio;

import com.leonardo.somethingiswrong.config.ConfigManager;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.Vec3d;

/** Toca sons posicionais so para um jogador (os demais nao ouvem). */
public final class Audio {
    private Audio() {}

    /** Som do mod; respeita a opcao customSounds. Retorna false se nao tocou. */
    public static boolean mod(ServerPlayerEntity p, SoundEvent s, Vec3d pos, float volume, float pitch) {
        if (!ConfigManager.get().customSounds) return false;
        return at(p, s, pos, volume, pitch);
    }

    /** Som qualquer (inclusive vanilla, ex.: passos). */
    public static boolean at(ServerPlayerEntity p, SoundEvent s, Vec3d pos, float volume, float pitch) {
        if (p.networkHandler == null) return false;
        p.networkHandler.sendPacket(new PlaySoundS2CPacket(Registries.SOUND_EVENT.getEntry(s), SoundCategory.AMBIENT,
                pos.x, pos.y, pos.z, volume, pitch, p.getRandom().nextLong()));
        return true;
    }
}
