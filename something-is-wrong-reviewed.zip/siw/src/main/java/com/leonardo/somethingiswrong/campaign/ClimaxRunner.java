package com.leonardo.somethingiswrong.campaign;

import java.util.List;

/** Avanca o final programado sobre o CampaignState. Idempotente: o final nunca roda duas vezes. */
public final class ClimaxRunner {
    private ClimaxRunner() {}

    /** Inicia o final. Retorna os passos do tick 0, ou lista vazia se ja iniciado/concluido. */
    public static List<ClimaxTimeline.Step> start(CampaignState st) {
        if (st.climax != ClimaxStatus.NOT_STARTED) return List.of();
        st.climax = ClimaxStatus.RUNNING;
        st.climaxTicks = 0;
        st.phase = Phase.CLIMAX;
        return ClimaxTimeline.at(0);
    }

    /** Avanca 1 tick. Ao executar FINISH marca o final como FINISHED. */
    public static List<ClimaxTimeline.Step> advance(CampaignState st) {
        if (st.climax != ClimaxStatus.RUNNING) return List.of();
        st.climaxTicks++;
        List<ClimaxTimeline.Step> due = ClimaxTimeline.at(st.climaxTicks);
        for (ClimaxTimeline.Step s : due) {
            if (s.action() == ClimaxTimeline.Action.FINISH) st.climax = ClimaxStatus.FINISHED;
        }
        if (st.climaxTicks > ClimaxTimeline.END_TICK) st.climax = ClimaxStatus.FINISHED;
        return due;
    }
}
