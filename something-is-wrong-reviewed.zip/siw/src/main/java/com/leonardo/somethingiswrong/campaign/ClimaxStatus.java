package com.leonardo.somethingiswrong.campaign;

public enum ClimaxStatus {
    NOT_STARTED, RUNNING, FINISHED;

    public static ClimaxStatus parse(String s) {
        if (s != null) {
            for (ClimaxStatus c : values()) if (c.name().equals(s)) return c;
        }
        return NOT_STARTED;
    }
}
