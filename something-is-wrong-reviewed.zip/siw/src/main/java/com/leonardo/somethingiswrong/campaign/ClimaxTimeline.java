package com.leonardo.somethingiswrong.campaign;

import java.util.ArrayList;
import java.util.List;

/** Linha do tempo (em ticks) do final programado. Todos os efeitos tem duracao finita e limitada. */
public final class ClimaxTimeline {
    public enum Action { FINAL_MESSAGE, SLOWNESS, BLINDNESS, SPAWN_WATCHER_NEAR, INTERFERENCE, SOUND_PEAK, ENDING_SCREEN, FINISH }

    /** a = duracao em ticks (ou intensidade para INTERFERENCE), b = amplificador (ou duracao da interferencia). */
    public record Step(long tick, Action action, int a, int b) {}

    public static final int MAX_EFFECT_TICKS = 400;
    public static final int MAX_AMPLIFIER = 1;
    public static final int MAX_BLINDNESS_TICKS = 100;
    public static final long END_TICK = 500;
    public static final int WATCHER_LIFETIME = 420;

    private static final List<Step> STEPS = new ArrayList<>();

    static {
        STEPS.add(new Step(0, Action.FINAL_MESSAGE, 0, 0));
        STEPS.add(new Step(0, Action.SLOWNESS, 400, 0));
        STEPS.add(new Step(0, Action.INTERFERENCE, 60, 200));
        STEPS.add(new Step(60, Action.SPAWN_WATCHER_NEAR, 0, 0));
        STEPS.add(new Step(100, Action.SLOWNESS, 300, 1));
        STEPS.add(new Step(160, Action.BLINDNESS, 60, 0));
        STEPS.add(new Step(260, Action.INTERFERENCE, 90, 200));
        STEPS.add(new Step(260, Action.SOUND_PEAK, 0, 0));
        STEPS.add(new Step(320, Action.BLINDNESS, 100, 0));
        STEPS.add(new Step(460, Action.ENDING_SCREEN, 0, 0));
        STEPS.add(new Step(END_TICK, Action.FINISH, 0, 0));
    }

    private ClimaxTimeline() {}

    public static List<Step> all() { return List.copyOf(STEPS); }

    public static List<Step> at(long tick) {
        List<Step> r = new ArrayList<>();
        for (Step s : STEPS) if (s.tick() == tick) r.add(s);
        return r;
    }

    /** Aplica os limites de seguranca a uma duracao de efeito. */
    public static int clampDuration(int ticks, boolean blindness) {
        return Math.max(1, Math.min(ticks, blindness ? MAX_BLINDNESS_TICKS : MAX_EFFECT_TICKS));
    }

    public static int clampAmplifier(int amp) {
        return Math.max(0, Math.min(amp, MAX_AMPLIFIER));
    }
}
