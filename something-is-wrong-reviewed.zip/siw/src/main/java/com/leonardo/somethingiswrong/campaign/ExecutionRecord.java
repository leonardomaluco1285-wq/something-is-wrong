package com.leonardo.somethingiswrong.campaign;

/** Registro de execucao de uma anomalia (contagem e ultimo tick da campanha). */
public final class ExecutionRecord {
    public int count;
    public long lastTick;

    public ExecutionRecord(int count, long lastTick) {
        this.count = count;
        this.lastTick = lastTick;
    }
}
