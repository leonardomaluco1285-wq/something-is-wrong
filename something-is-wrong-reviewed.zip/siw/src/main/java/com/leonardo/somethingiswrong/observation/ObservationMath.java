package com.leonardo.somethingiswrong.observation;

/** Matematica pura da observacao (distancia + campo de visao). Linha de visao e feita na camada do servidor. */
public final class ObservationMath {
    public enum View { OUT_OF_RANGE, OUTSIDE_FOV, IN_VIEW }

    private ObservationMath() {}

    public static View classify(double eyeX, double eyeY, double eyeZ,
                                double lookX, double lookY, double lookZ,
                                double tx, double ty, double tz,
                                double minDist, double maxDist, double halfAngleDegrees) {
        double dx = tx - eyeX, dy = ty - eyeY, dz = tz - eyeZ;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist < minDist || dist > maxDist) return View.OUT_OF_RANGE;
        double ll = Math.sqrt(lookX * lookX + lookY * lookY + lookZ * lookZ);
        if (ll < 1e-9 || dist < 1e-9) return View.OUT_OF_RANGE;
        double cos = (dx * lookX + dy * lookY + dz * lookZ) / (dist * ll);
        double limit = Math.cos(Math.toRadians(halfAngleDegrees));
        return cos >= limit ? View.IN_VIEW : View.OUTSIDE_FOV;
    }
}
