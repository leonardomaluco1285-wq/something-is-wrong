package com.leonardo.somethingiswrong.persistence;

import com.leonardo.somethingiswrong.SomethingIsWrongMod;
import com.leonardo.somethingiswrong.campaign.CampaignState;
import com.leonardo.somethingiswrong.config.ConfigManager;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

/**
 * Persistencia no mundo (data/somethingiswrong_campaign.dat). Usa o mecanismo de salvamento do proprio
 * Minecraft: o estado so e gravado quando marcado como "sujo" e o mundo e salvo, sem arquivos extras
 * por segundo. Dados ausentes/corrompidos resultam em uma campanha nova (recuperacao segura).
 */
public class CampaignPersistentState extends PersistentState {
    public static final String KEY = "somethingiswrong_campaign";

    public static final PersistentState.Type<CampaignPersistentState> TYPE = new PersistentState.Type<>(
            CampaignPersistentState::new, CampaignPersistentState::fromNbt, null);

    public final CampaignState state;

    public CampaignPersistentState() {
        this.state = new CampaignState();
    }

    private CampaignPersistentState(CampaignState state) {
        this.state = state;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        nbt.put("campaign", NbtMapCodec.toNbt(state.toMap()));
        return nbt;
    }

    public static CampaignPersistentState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        try {
            CampaignState s = CampaignState.fromMap(NbtMapCodec.fromNbt(nbt.getCompound("campaign")));
            s.validate(ConfigManager.get().campaignMinutes);
            return new CampaignPersistentState(s);
        } catch (Exception e) {
            SomethingIsWrongMod.LOGGER.warn("Estado da campanha ilegivel, iniciando limpo: {}", e.toString());
            return new CampaignPersistentState();
        }
    }

    public static CampaignPersistentState get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE, KEY);
    }
}
