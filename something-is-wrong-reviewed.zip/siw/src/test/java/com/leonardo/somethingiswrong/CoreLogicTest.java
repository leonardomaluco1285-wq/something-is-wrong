package com.leonardo.somethingiswrong;

import com.leonardo.somethingiswrong.anomaly.*;
import com.leonardo.somethingiswrong.campaign.*;
import com.leonardo.somethingiswrong.config.ModSettings;
import com.leonardo.somethingiswrong.observation.ObservationMath;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class CoreLogicTest {

    private static CampaignState started() {
        CampaignState s = new CampaignState();
        s.start();
        return s;
    }

    private static long ticksAtMinute(double min) { return (long) (min * 60 * 20); }

    // ---------- progressao das fases ----------
    @Test
    void phasesFollowTimeBands() {
        ModSettings cfg = new ModSettings();
        CampaignState s = started();
        double[] mins = {0, 2.99, 3, 5.9, 6, 9, 12, 15, 18, 19.9};
        Phase[] exp = {Phase.NORMALITY, Phase.NORMALITY, Phase.COINCIDENCES, Phase.COINCIDENCES, Phase.SOMETHING_WRONG,
                Phase.PRESENCE, Phase.ENTITY, Phase.RUPTURE, Phase.CLIMAX, Phase.CLIMAX};
        for (int i = 0; i < mins.length; i++) {
            s.elapsedTicks = ticksAtMinute(mins[i]);
            assertEquals(exp[i], CampaignClock.phaseOf(s, cfg), "min " + mins[i]);
        }
    }

    @Test
    void clockAdvancesAndReportsTransitionsInOrder() {
        ModSettings cfg = new ModSettings();
        CampaignState s = started();
        List<Phase> seen = new ArrayList<>();
        for (long t = 0; t < ticksAtMinute(20); t++) {
            CampaignClock.advance(s, cfg, 1).ifPresent(seen::add);
        }
        assertEquals(List.of(Phase.COINCIDENCES, Phase.SOMETHING_WRONG, Phase.PRESENCE, Phase.ENTITY, Phase.RUPTURE, Phase.CLIMAX), seen);
        assertTrue(CampaignClock.finaleDue(s, cfg));
    }

    @Test
    void campaignLengthScalesPhases() {
        ModSettings cfg = new ModSettings();
        cfg.campaignMinutes = 10;
        CampaignState s = started();
        s.elapsedTicks = ticksAtMinute(1.5); // = 3 min na escala de 20
        assertEquals(Phase.COINCIDENCES, CampaignClock.phaseOf(s, cfg));
        s.elapsedTicks = ticksAtMinute(10);
        assertTrue(CampaignClock.finaleDue(s, cfg));
    }

    @Test
    void clockDoesNotAdvanceBeforeStartOrAfterClimax() {
        ModSettings cfg = new ModSettings();
        CampaignState s = new CampaignState();
        CampaignClock.advance(s, cfg, 100);
        assertEquals(0, s.elapsedTicks);
        s.start();
        s.climax = ClimaxStatus.RUNNING;
        CampaignClock.advance(s, cfg, 100);
        assertEquals(0, s.elapsedTicks);
    }

    @Test
    void jumpToNextPhaseWorks() {
        ModSettings cfg = new ModSettings();
        CampaignState s = started();
        CampaignClock.jumpToNextPhase(s, cfg);
        assertEquals(Phase.COINCIDENCES, s.phase);
        for (int i = 0; i < 10; i++) CampaignClock.jumpToNextPhase(s, cfg);
        assertTrue(CampaignClock.finaleDue(s, cfg));
    }

    // ---------- selecao e intervalos ----------
    private static SafetyContext calm() { return SafetyContext.calm(); }

    @Test
    void nothingRunsInNormalityPhase() {
        ModSettings cfg = new ModSettings();
        CampaignState s = started();
        long now = ticksAtMinute(2.9);
        for (AnomalyDefinition d : AnomalyRegistry.all()) {
            assertNotNull(AnomalyScheduler.rejection(d, s, cfg, calm(), now), d.id);
        }
    }

    @Test
    void windowsAreRespected() {
        ModSettings cfg = new ModSettings();
        CampaignState s = started();
        AnomalyDefinition vanish = AnomalyRegistry.get(AnomalyRegistry.WATCHER_VANISH);
        assertEquals("window", AnomalyScheduler.rejection(vanish, s, cfg, calm(), ticksAtMinute(11.9)));
        assertNull(AnomalyScheduler.rejection(vanish, s, cfg, calm(), ticksAtMinute(12.1)));
        assertEquals("window", AnomalyScheduler.rejection(vanish, s, cfg, calm(), ticksAtMinute(18.1)));
    }

    @Test
    void cooldownAndGlobalGapAreRespected() {
        ModSettings cfg = new ModSettings();
        CampaignState s = started();
        AnomalyDefinition d = AnomalyRegistry.get(AnomalyRegistry.ODD_SOUND);
        long t0 = ticksAtMinute(5);
        AnomalyScheduler.record(s, d, t0);
        assertEquals("cooldown", AnomalyScheduler.rejection(d, s, cfg, calm(), t0 + d.cooldownTicks - 1));
        AnomalyDefinition other = AnomalyRegistry.get(AnomalyRegistry.CLOSE_NOISE);
        assertEquals("global_gap", AnomalyScheduler.rejection(other, s, cfg, calm(), t0 + 10));
        assertNull(AnomalyScheduler.rejection(d, s, cfg, calm(), t0 + d.cooldownTicks));
    }

    @Test
    void repeatLimitIsRespected() {
        ModSettings cfg = new ModSettings();
        CampaignState s = started();
        AnomalyDefinition d = AnomalyRegistry.get(AnomalyRegistry.FOOTSTEPS);
        long now = ticksAtMinute(7);
        for (int i = 0; i < d.maxRepeats; i++) {
            AnomalyScheduler.record(s, d, now);
            now += 20000;
            if (now > ticksAtMinute(16)) now = ticksAtMinute(16);
        }
        s.lastAnyEventTick = -1;
        s.executed.get(d.id).lastTick = 0;
        assertEquals("max_repeats", AnomalyScheduler.rejection(d, s, cfg, calm(), ticksAtMinute(10)));
    }

    @Test
    void unsafeContextBlocksEverything() {
        ModSettings cfg = new ModSettings();
        CampaignState s = started();
        long now = ticksAtMinute(13);
        SafetyContext combat = calm().withInCombat(true);
        assertTrue(AnomalyScheduler.eligible(AnomalyRegistry.all(), s, cfg, combat, now).isEmpty());
        assertFalse(AnomalyScheduler.eligible(AnomalyRegistry.all(), s, cfg, calm(), now).isEmpty());
    }

    @Test
    void requirementsAreChecked() {
        ModSettings cfg = new ModSettings();
        CampaignState s = started();
        AnomalyDefinition sil = AnomalyRegistry.get(AnomalyRegistry.SILHOUETTE);
        long now = ticksAtMinute(8);
        assertNull(AnomalyScheduler.rejection(sil, s, cfg, calm(), now));
        assertEquals("requirement:OUTDOORS", AnomalyScheduler.rejection(sil, s, cfg, calm().withUnderground(true), now));
        AnomalyDefinition fl = AnomalyRegistry.get(AnomalyRegistry.WATCHER_FLICKER);
        assertEquals("requirement:NO_WATCHER", AnomalyScheduler.rejection(fl, s, cfg, calm().withWatcherPresent(true), ticksAtMinute(10)));
    }

    @Test
    void visualInterferenceCanBeDisabled() {
        ModSettings cfg = new ModSettings();
        cfg.visualInterference = false;
        CampaignState s = started();
        AnomalyDefinition d = AnomalyRegistry.get(AnomalyRegistry.INTERFERENCE);
        assertEquals("visual_off", AnomalyScheduler.rejection(d, s, cfg, calm(), ticksAtMinute(10)));
    }

    @Test
    void finalIsScriptedAndNeverDrawn() {
        ModSettings cfg = new ModSettings();
        CampaignState s = started();
        Random r = new Random(1);
        for (int i = 0; i < 2000; i++) {
            Optional<AnomalyDefinition> p = AnomalyScheduler.select(AnomalyRegistry.all(), s, cfg, calm(), ticksAtMinute(14) + i * 7L, r);
            p.ifPresent(d -> assertNotEquals(AnomalyRegistry.FINALE, d.id));
        }
    }

    @Test
    void firstMainAppearanceIsPrioritisedAfterMinute12() {
        ModSettings cfg = new ModSettings();
        CampaignState s = started();
        Optional<AnomalyDefinition> p = AnomalyScheduler.select(AnomalyRegistry.all(), s, cfg, calm(), ticksAtMinute(12.2), new Random(5));
        assertTrue(p.isPresent());
        assertEquals(AnomalyRegistry.WATCHER_VANISH, p.get().id);
    }

    @Test
    void selectionNeverProducesDuplicatesWithinGap() {
        ModSettings cfg = new ModSettings();
        CampaignState s = started();
        Random r = new Random(42);
        long now = ticksAtMinute(8);
        long lastRun = -1;
        int runs = 0;
        for (long t = now; t < ticksAtMinute(17); t += AnomalyScheduler.ATTEMPT_INTERVAL_TICKS) {
            Optional<AnomalyDefinition> p = AnomalyScheduler.select(AnomalyRegistry.all(), s, cfg, calm(), t, r);
            if (p.isPresent()) {
                if (lastRun >= 0) assertTrue(t - lastRun >= AnomalyScheduler.globalGapTicks(cfg));
                AnomalyScheduler.record(s, p.get(), t);
                lastRun = t;
                runs++;
            }
        }
        assertTrue(runs > 0 && runs < 60, "runs=" + runs);
        for (AnomalyDefinition d : AnomalyRegistry.all()) assertTrue(s.countOf(d.id) <= d.maxRepeats);
    }

    @Test
    void zeroIntensityAndOverridesChangeChance() {
        ModSettings cfg = new ModSettings();
        CampaignState s = started();
        AnomalyDefinition d = AnomalyRegistry.get(AnomalyRegistry.ODD_SOUND);
        long now = ticksAtMinute(10);
        double base = AnomalyScheduler.effectiveChance(d, s, cfg, now);
        cfg.anomalyChance.put(d.id, 0.0);
        assertEquals(0.0, AnomalyScheduler.effectiveChance(d, s, cfg, now));
        cfg.anomalyChance.clear();
        cfg.intensity = 100;
        assertTrue(AnomalyScheduler.effectiveChance(d, s, cfg, now) > base);
    }

    @Test
    void registryHasAtLeastTenAnomaliesWithUniqueIds() {
        List<String> ids = AnomalyRegistry.ids();
        assertTrue(ids.size() >= 10);
        assertEquals(ids.size(), new HashSet<>(ids).size());
    }

    // ---------- persistencia ----------
    @Test
    void stateRoundTripsThroughMap() {
        ModSettings cfg = new ModSettings();
        CampaignState s = started();
        s.elapsedTicks = ticksAtMinute(13);
        s.phase = Phase.ENTITY;
        AnomalyScheduler.record(s, AnomalyRegistry.get(AnomalyRegistry.ODD_SOUND), s.elapsedTicks);
        s.watcherUuid = "abc";
        CampaignState r = CampaignState.fromMap(s.toMap());
        r.validate(cfg.campaignMinutes);
        assertEquals(s.campaignId, r.campaignId);
        assertEquals(s.elapsedTicks, r.elapsedTicks);
        assertEquals(1, r.countOf(AnomalyRegistry.ODD_SOUND));
        assertEquals(s.lastAnyEventTick, r.lastAnyEventTick);
        assertEquals("abc", r.watcherUuid);
        assertEquals(Phase.ENTITY, r.phase);
    }

    @Test
    void corruptOrMissingDataRecoversSafely() {
        Map<String, Object> bad = new HashMap<>();
        bad.put("elapsedTicks", "nao-e-numero");
        bad.put("executed", "lixo");
        bad.put("climax", "INEXISTENTE");
        bad.put("started", 5);
        CampaignState s = CampaignState.fromMap(bad);
        s.validate(20);
        assertEquals(0, s.elapsedTicks);
        assertEquals(ClimaxStatus.NOT_STARTED, s.climax);
        assertTrue(s.started);
        assertFalse(s.campaignId.isEmpty());
        CampaignState n = CampaignState.fromMap(null);
        n.validate(20);
        assertFalse(n.started);
    }

    @Test
    void validateFixesImpossibleState() {
        CampaignState s = new CampaignState();
        s.started = true;
        s.elapsedTicks = -50;
        s.climax = ClimaxStatus.RUNNING;
        s.climaxTicks = 99999;
        s.executed.put("x", new ExecutionRecord(-1, 3));
        s.validate(20);
        assertEquals(0, s.elapsedTicks);
        assertEquals(ClimaxStatus.FINISHED, s.climax);
        assertTrue(s.executed.isEmpty());
    }

    @Test
    void resetClearsCampaignOnly() {
        CampaignState s = started();
        s.elapsedTicks = 5000;
        AnomalyScheduler.record(s, AnomalyRegistry.get(AnomalyRegistry.FOOTSTEPS), 5000);
        s.climax = ClimaxStatus.FINISHED;
        s.reset();
        assertFalse(s.started);
        assertEquals(0, s.elapsedTicks);
        assertTrue(s.executed.isEmpty());
        assertEquals(ClimaxStatus.NOT_STARTED, s.climax);
        assertEquals(Phase.NORMALITY, s.phase);
        assertEquals(-1, s.lastAnyEventTick);
    }

    // ---------- climax ----------
    @Test
    void climaxRunsOnceAndFinishes() {
        CampaignState s = started();
        assertFalse(ClimaxRunner.start(s).isEmpty());
        assertEquals(ClimaxStatus.RUNNING, s.climax);
        assertTrue(ClimaxRunner.start(s).isEmpty(), "nao pode iniciar de novo");
        boolean sawEnding = false, sawFinish = false;
        int guard = 0;
        while (s.climax == ClimaxStatus.RUNNING && guard++ < 10000) {
            for (ClimaxTimeline.Step st : ClimaxRunner.advance(s)) {
                if (st.action() == ClimaxTimeline.Action.ENDING_SCREEN) sawEnding = true;
                if (st.action() == ClimaxTimeline.Action.FINISH) sawFinish = true;
            }
        }
        assertTrue(guard < 10000);
        assertTrue(sawEnding && sawFinish);
        assertEquals(ClimaxStatus.FINISHED, s.climax);
        assertTrue(ClimaxRunner.start(s).isEmpty());
        assertTrue(ClimaxRunner.advance(s).isEmpty());
    }

    @Test
    void climaxEffectsAreBoundedAndRecoverable() {
        long maxEnd = 0;
        for (ClimaxTimeline.Step st : ClimaxTimeline.all()) {
            if (st.action() == ClimaxTimeline.Action.SLOWNESS) {
                assertTrue(st.a() <= ClimaxTimeline.MAX_EFFECT_TICKS);
                assertTrue(st.b() <= ClimaxTimeline.MAX_AMPLIFIER);
                maxEnd = Math.max(maxEnd, st.tick() + st.a());
            }
            if (st.action() == ClimaxTimeline.Action.BLINDNESS) {
                assertTrue(st.a() <= ClimaxTimeline.MAX_BLINDNESS_TICKS);
                maxEnd = Math.max(maxEnd, st.tick() + st.a());
            }
            assertTrue(st.tick() <= ClimaxTimeline.END_TICK);
        }
        assertTrue(maxEnd <= ClimaxTimeline.END_TICK + ClimaxTimeline.MAX_EFFECT_TICKS);
        assertEquals(ClimaxTimeline.MAX_EFFECT_TICKS, ClimaxTimeline.clampDuration(1_000_000, false));
        assertEquals(ClimaxTimeline.MAX_BLINDNESS_TICKS, ClimaxTimeline.clampDuration(1_000_000, true));
        assertEquals(1, ClimaxTimeline.clampAmplifier(255));
    }

    @Test
    void climaxResumesFromSavedTickWithoutRepeatingFinal() {
        CampaignState s = started();
        ClimaxRunner.start(s);
        for (int i = 0; i < 200; i++) ClimaxRunner.advance(s);
        CampaignState r = CampaignState.fromMap(s.toMap());
        r.validate(20);
        assertEquals(ClimaxStatus.RUNNING, r.climax);
        assertEquals(200, r.climaxTicks);
        assertTrue(ClimaxRunner.start(r).isEmpty());
        while (r.climax == ClimaxStatus.RUNNING) ClimaxRunner.advance(r);
        CampaignState done = CampaignState.fromMap(r.toMap());
        done.validate(20);
        assertEquals(ClimaxStatus.FINISHED, done.climax);
        assertTrue(ClimaxRunner.start(done).isEmpty());
    }

    // ---------- configuracao ----------
    @Test
    void settingsAreValidated() {
        ModSettings c = new ModSettings();
        c.intensity = 900;
        c.eventFrequency = Double.NaN;
        c.campaignMinutes = 0;
        c.observationMinDistance = -4;
        c.observationMaxDistance = 1;
        c.anomalyChance.put("a", 9.0);
        c.anomalyChance.put("b", 0.5);
        List<String> warnings = c.sanitize();
        assertFalse(warnings.isEmpty());
        assertEquals(100, c.intensity);
        assertEquals(1.0, c.eventFrequency);
        assertEquals(3, c.campaignMinutes);
        assertEquals(2.0, c.observationMinDistance);
        assertEquals(96.0, c.observationMaxDistance);
        assertFalse(c.anomalyChance.containsKey("a"));
        assertEquals(0.5, c.anomalyChance.get("b").doubleValue());
        assertTrue(new ModSettings().sanitize().isEmpty());
    }

    @Test
    void disabledModBlocksAnomalies() {
        ModSettings cfg = new ModSettings();
        cfg.enabled = false;
        CampaignState s = started();
        assertTrue(AnomalyScheduler.eligible(AnomalyRegistry.all(), s, cfg, calm(), ticksAtMinute(13)).isEmpty());
    }

    // ---------- observacao ----------
    @Test
    void observationDetectsDirectLook() {
        // jogador na origem olhando para +z, alvo a 10 blocos a frente
        assertEquals(ObservationMath.View.IN_VIEW, ObservationMath.classify(0, 1.6, 0, 0, 0, 1, 0, 1.6, 10, 2, 96, 28));
        // alvo atras
        assertEquals(ObservationMath.View.OUTSIDE_FOV, ObservationMath.classify(0, 1.6, 0, 0, 0, 1, 0, 1.6, -10, 2, 96, 28));
        // alvo a 45 graus (fora do cone de 28)
        assertEquals(ObservationMath.View.OUTSIDE_FOV, ObservationMath.classify(0, 0, 0, 0, 0, 1, 10, 0, 10, 2, 96, 28));
        // muito perto / muito longe
        assertEquals(ObservationMath.View.OUT_OF_RANGE, ObservationMath.classify(0, 0, 0, 0, 0, 1, 0, 0, 1, 2, 96, 28));
        assertEquals(ObservationMath.View.OUT_OF_RANGE, ObservationMath.classify(0, 0, 0, 0, 0, 1, 0, 0, 200, 2, 96, 28));
    }

    // ---------- comportamento ----------
    @Test
    void behaviorTrackerClassifiesPlayers() {
        BehaviorTracker t = new BehaviorTracker();
        assertEquals(BehaviorTracker.Trait.NONE, t.dominant());
        for (int i = 0; i < 30; i++) t.sample(true, false);
        assertEquals(BehaviorTracker.Trait.STATIONARY, t.dominant());
        BehaviorTracker u = new BehaviorTracker();
        for (int i = 0; i < 40; i++) u.sample(false, true);
        assertEquals(BehaviorTracker.Trait.UNDERGROUND, u.dominant());
        BehaviorTracker e = new BehaviorTracker();
        for (int i = 0; i < 40; i++) e.sample(false, false);
        assertEquals(BehaviorTracker.Trait.EXPLORER, e.dominant());
        e.noteWatcherLook();
        e.noteWatcherLook();
        assertEquals(BehaviorTracker.Trait.LOOKER, e.dominant());
        e.consumeLooks();
        assertEquals(BehaviorTracker.Trait.EXPLORER, e.dominant());
    }
}
